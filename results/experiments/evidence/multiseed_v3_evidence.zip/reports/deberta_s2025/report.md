# microsoft/deberta-v3-base

All values below come from recorded artifacts; missing evidence is stated explicitly.

## Dev split

- Weighted F1: 0.6209228963086096
- Macro F1: 0.4982216125113156
- Accuracy: 0.6212804328223624

![Confusion matrix](dev_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7433 | 0.7638 | 0.7534 | 470 |
| joy | 0.6454 | 0.5583 | 0.5987 | 163 |
| surprise | 0.6139 | 0.6467 | 0.6299 | 150 |
| anger | 0.4596 | 0.4837 | 0.4713 | 153 |
| sadness | 0.5056 | 0.4054 | 0.4500 | 111 |
| disgust | 0.1538 | 0.1818 | 0.1667 | 22 |
| fear | 0.3725 | 0.4750 | 0.4176 | 40 |

Lowest class F1: disgust, fear. Inspect real errors before assigning causes.

Examples: [dev_review_examples.csv](dev_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Test split

- Weighted F1: 0.6466934040243704
- Macro F1: 0.4922334871308994
- Accuracy: 0.6436781609195402

![Confusion matrix](test_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7943 | 0.7596 | 0.7766 | 1256 |
| joy | 0.6352 | 0.6368 | 0.6360 | 402 |
| surprise | 0.5528 | 0.5587 | 0.5558 | 281 |
| anger | 0.4975 | 0.5739 | 0.5330 | 345 |
| sadness | 0.4205 | 0.3942 | 0.4069 | 208 |
| disgust | 0.3542 | 0.2500 | 0.2931 | 68 |
| fear | 0.1975 | 0.3200 | 0.2443 | 50 |

Lowest class F1: fear, disgust. Inspect real errors before assigning causes.

Examples: [test_review_examples.csv](test_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Learning curves

![Learning curves](learning_curves.png)

Training points are logged batch losses; validation points use the validation set.

## Measured hardware and efficiency

See [hardware.json](hardware.json).

Latency is batch 1 including preprocessing, forward and postprocessing, excluding loading.

## Run configuration

~~~json
{
  "model_name": "microsoft/deberta-v3-base",
  "data_dir": "/content/drive/MyDrive/diploma-mer/data/meld",
  "output_dir": "/content/drive/MyDrive/diploma-mer/defense/defense_multiseed_v3/deberta_s2025",
  "checkpoint_dir": "/content/checkpoints/defense_multiseed_v3/deberta_s2025",
  "n_context": 3,
  "n_future": 0,
  "with_speaker": true,
  "max_length": 256,
  "epochs": 6,
  "lr": 2e-05,
  "batch_size": 4,
  "grad_accum": 4,
  "weight_decay": 0.01,
  "warmup_ratio": 0.1,
  "class_weights": true,
  "class_weight_power": 0.5,
  "focal_gamma": 0.0,
  "early_stopping_patience": 2,
  "gradient_checkpointing": true,
  "seed": 2025,
  "limit_train": null,
  "limit_eval": null,
  "save_model": true,
  "evaluate_test": false,
  "save_only_model": true,
  "resume_from_checkpoint": null,
  "logging_steps": 25,
  "save_probs": true
}
~~~

## Evidence gaps / limitations


Text-only English MELD / Friends dialogues; multilingual and clinical performance is unvalidated.
Softmax confidence is not a calibrated probability of correctness.
Test error inspection is final reporting, not another hyperparameter-selection round.
