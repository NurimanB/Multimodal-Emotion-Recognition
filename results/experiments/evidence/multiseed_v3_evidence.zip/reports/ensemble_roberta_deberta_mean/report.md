# RoBERTa + 3-seed DeBERTa mean

All values below come from recorded artifacts; missing evidence is stated explicitly.

## Dev split

- Weighted F1: 0.668961761075968
- Macro F1: 0.5643211811900174
- Accuracy: 0.678990081154193

![Confusion matrix](dev_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7247 | 0.8681 | 0.7899 | 470 |
| joy | 0.6757 | 0.6135 | 0.6431 | 163 |
| surprise | 0.6824 | 0.6733 | 0.6779 | 150 |
| anger | 0.6396 | 0.4641 | 0.5379 | 153 |
| sadness | 0.6267 | 0.4234 | 0.5054 | 111 |
| disgust | 0.3200 | 0.3636 | 0.3404 | 22 |
| fear | 0.4615 | 0.4500 | 0.4557 | 40 |

Lowest class F1: disgust, fear. Inspect real errors before assigning causes.

Examples: [dev_review_examples.csv](dev_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Test split

- Weighted F1: 0.6680791110593878
- Macro F1: 0.5112797606007202
- Accuracy: 0.6773946360153257

![Confusion matrix](test_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7662 | 0.8559 | 0.8086 | 1256 |
| joy | 0.6485 | 0.6517 | 0.6501 | 402 |
| surprise | 0.5912 | 0.5765 | 0.5838 | 281 |
| anger | 0.5971 | 0.4725 | 0.5275 | 345 |
| sadness | 0.5224 | 0.3365 | 0.4094 | 208 |
| disgust | 0.3519 | 0.2794 | 0.3115 | 68 |
| fear | 0.2500 | 0.3400 | 0.2881 | 50 |

Lowest class F1: fear, disgust. Inspect real errors before assigning causes.

Examples: [test_review_examples.csv](test_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Evidence gaps / limitations

- Learning curves: trainer_state.json/log_history unavailable; no curve was invented.
- Hardware, parameter count and latency: not measured in this legacy JSON.

Text-only English MELD / Friends dialogues; multilingual and clinical performance is unvalidated.
Softmax confidence is not a calibrated probability of correctness.
Test error inspection is final reporting, not another hyperparameter-selection round.
