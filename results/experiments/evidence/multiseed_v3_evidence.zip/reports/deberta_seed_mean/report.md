# DeBERTa-v3-base mean of seeds 42,123,2025

All values below come from recorded artifacts; missing evidence is stated explicitly.

## Dev split

- Weighted F1: 0.6393281565713327
- Macro F1: 0.5222538810217177
- Accuracy: 0.6429215509467989

![Confusion matrix](dev_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7470 | 0.7851 | 0.7656 | 470 |
| joy | 0.6182 | 0.6258 | 0.6220 | 163 |
| surprise | 0.6306 | 0.6600 | 0.6450 | 150 |
| anger | 0.5182 | 0.4641 | 0.4897 | 153 |
| sadness | 0.5258 | 0.4595 | 0.4904 | 111 |
| disgust | 0.2174 | 0.2273 | 0.2222 | 22 |
| fear | 0.4444 | 0.4000 | 0.4211 | 40 |

Lowest class F1: disgust, fear. Inspect real errors before assigning causes.

Examples: [dev_review_examples.csv](dev_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Test split

- Weighted F1: 0.6586458432681012
- Macro F1: 0.5065256786199763
- Accuracy: 0.6582375478927203

![Confusion matrix](test_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7993 | 0.7803 | 0.7897 | 1256 |
| joy | 0.6022 | 0.6816 | 0.6394 | 402 |
| surprise | 0.5818 | 0.5694 | 0.5755 | 281 |
| anger | 0.5532 | 0.5275 | 0.5401 | 345 |
| sadness | 0.4101 | 0.4279 | 0.4188 | 208 |
| disgust | 0.3958 | 0.2794 | 0.3276 | 68 |
| fear | 0.2333 | 0.2800 | 0.2545 | 50 |

Lowest class F1: fear, disgust. Inspect real errors before assigning causes.

Examples: [test_review_examples.csv](test_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Run configuration

~~~json
{
  "model_name": "DeBERTa-v3-base mean of seeds 42,123,2025",
  "seeds": [
    42,
    123,
    2025
  ],
  "member_runs": [
    "/content/drive/MyDrive/diploma-mer/defense/defense_multiseed_v3/reused_inputs/deberta_s42",
    "/content/drive/MyDrive/diploma-mer/defense/defense_multiseed_v3/deberta_s123",
    "/content/drive/MyDrive/diploma-mer/defense/defense_multiseed_v3/deberta_s2025"
  ],
  "mean_weights": [
    0.3333333333333333,
    0.3333333333333333,
    0.3333333333333333
  ],
  "selection_split": "dev"
}
~~~

## Evidence gaps / limitations

- Learning curves: trainer_state.json/log_history unavailable; no curve was invented.
- Hardware, parameter count and latency: not measured in this legacy JSON.

Text-only English MELD / Friends dialogues; multilingual and clinical performance is unvalidated.
Softmax confidence is not a calibrated probability of correctness.
Test error inspection is final reporting, not another hyperparameter-selection round.
