# microsoft/deberta-v3-base

All values below come from recorded artifacts; missing evidence is stated explicitly.

## Dev split

- Weighted F1: 0.6312728919575262
- Macro F1: 0.5121209343166836
- Accuracy: 0.6330027051397655

![Confusion matrix](dev_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7666 | 0.7617 | 0.7641 | 470 |
| joy | 0.5889 | 0.6503 | 0.6181 | 163 |
| surprise | 0.6289 | 0.6667 | 0.6472 | 150 |
| anger | 0.5410 | 0.4314 | 0.4800 | 153 |
| sadness | 0.4091 | 0.4865 | 0.4444 | 111 |
| disgust | 0.2727 | 0.2727 | 0.2727 | 22 |
| fear | 0.4444 | 0.3000 | 0.3582 | 40 |

Lowest class F1: disgust, fear. Inspect real errors before assigning causes.

Examples: [dev_review_examples.csv](dev_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Test split

- Weighted F1: 0.6429991202021946
- Macro F1: 0.4934182613542732
- Accuracy: 0.6402298850574712

![Confusion matrix](test_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7992 | 0.7508 | 0.7742 | 1256 |
| joy | 0.5674 | 0.7015 | 0.6274 | 402 |
| surprise | 0.5797 | 0.5694 | 0.5745 | 281 |
| anger | 0.5657 | 0.4493 | 0.5008 | 345 |
| sadness | 0.3674 | 0.4663 | 0.4110 | 208 |
| disgust | 0.3134 | 0.3088 | 0.3111 | 68 |
| fear | 0.2500 | 0.2600 | 0.2549 | 50 |

Lowest class F1: fear, disgust. Inspect real errors before assigning causes.

Examples: [test_review_examples.csv](test_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Learning curves

![Learning curves](learning_curves.png)

Training points are logged batch losses; validation points use the validation set.

## Measured hardware and efficiency

See [hardware.json](hardware.json).

Latency is batch 1 including preprocessing, forward and postprocessing, excluding loading.

## Run configuration

~~~json
{
  "model_name": "microsoft/deberta-v3-base",
  "data_dir": "/content/drive/MyDrive/diploma-mer/data/meld",
  "output_dir": "/content/drive/MyDrive/diploma-mer/defense/defense_multiseed_v3/deberta_s123",
  "checkpoint_dir": "/content/checkpoints/defense_multiseed_v3/deberta_s123",
  "n_context": 3,
  "n_future": 0,
  "with_speaker": true,
  "max_length": 256,
  "epochs": 6,
  "lr": 2e-05,
  "batch_size": 4,
  "grad_accum": 4,
  "weight_decay": 0.01,
  "warmup_ratio": 0.1,
  "class_weights": true,
  "class_weight_power": 0.5,
  "focal_gamma": 0.0,
  "early_stopping_patience": 2,
  "gradient_checkpointing": true,
  "seed": 123,
  "limit_train": null,
  "limit_eval": null,
  "save_model": true,
  "evaluate_test": false,
  "save_only_model": true,
  "resume_from_checkpoint": null,
  "logging_steps": 25,
  "save_probs": true
}
~~~

## Evidence gaps / limitations


Text-only English MELD / Friends dialogues; multilingual and clinical performance is unvalidated.
Softmax confidence is not a calibrated probability of correctness.
Test error inspection is final reporting, not another hyperparameter-selection round.
