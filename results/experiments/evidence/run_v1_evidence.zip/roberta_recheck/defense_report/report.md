# FacebookAI/roberta-large

All values below come from recorded artifacts; missing evidence is stated explicitly.

## Dev split

- Weighted F1: 0.6373663945840654
- Macro F1: 0.5277806415850259
- Accuracy: 0.630297565374211

![Confusion matrix](dev_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.8080 | 0.6894 | 0.7440 | 470 |
| joy | 0.5340 | 0.6748 | 0.5962 | 163 |
| surprise | 0.5539 | 0.7533 | 0.6384 | 150 |
| anger | 0.7143 | 0.4902 | 0.5814 | 153 |
| sadness | 0.5444 | 0.4414 | 0.4876 | 111 |
| disgust | 0.2051 | 0.3636 | 0.2623 | 22 |
| fear | 0.3125 | 0.5000 | 0.3846 | 40 |

Lowest class F1: disgust, fear. Inspect real errors before assigning causes.

Examples: [dev_review_examples.csv](dev_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Test split

- Weighted F1: 0.6132319286526161
- Macro F1: 0.47610656860684714
- Accuracy: 0.6019157088122605

![Confusion matrix](test_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.8275 | 0.6568 | 0.7324 | 1256 |
| joy | 0.5439 | 0.7090 | 0.6156 | 402 |
| surprise | 0.4619 | 0.6904 | 0.5535 | 281 |
| anger | 0.5504 | 0.4116 | 0.4710 | 345 |
| sadness | 0.4086 | 0.3654 | 0.3858 | 208 |
| disgust | 0.2929 | 0.4265 | 0.3473 | 68 |
| fear | 0.1587 | 0.4000 | 0.2273 | 50 |

Lowest class F1: fear, disgust. Inspect real errors before assigning causes.

Examples: [test_review_examples.csv](test_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Learning curves

![Learning curves](learning_curves.png)

Training points are logged batch losses; validation points use the validation set.

## Measured hardware and efficiency

See [hardware.json](hardware.json).

Latency is batch 1 including preprocessing, forward and postprocessing, excluding loading.

## Run configuration

~~~json
{
  "n_context": 3,
  "n_future": 0,
  "with_speaker": true,
  "max_length": 256,
  "model_name": "FacebookAI/roberta-large",
  "data_dir": "/content/drive/MyDrive/diploma-mer/data/meld",
  "output_dir": "/content/drive/MyDrive/diploma-mer/outputs/text_roberta_large_ctx3",
  "checkpoint_dir": "checkpoints/text_roberta_large_ctx3",
  "epochs": 6,
  "lr": 1e-05,
  "batch_size": 8,
  "grad_accum": 2,
  "weight_decay": 0.01,
  "warmup_ratio": 0.1,
  "class_weights": true,
  "early_stopping_patience": 2,
  "gradient_checkpointing": false,
  "seed": 42,
  "limit_train": null,
  "limit_eval": null,
  "save_model": false
}
~~~

## Evidence gaps / limitations


Text-only English MELD / Friends dialogues; multilingual and clinical performance is unvalidated.
Softmax confidence is not a calibrated probability of correctness.
Test error inspection is final reporting, not another hyperparameter-selection round.
