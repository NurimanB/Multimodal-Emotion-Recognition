# TF-IDF + Logistic Regression

All values below come from recorded artifacts; missing evidence is stated explicitly.

## Dev split

- Weighted F1: 0.4189592207080023
- Macro F1: 0.29669885024924125
- Accuracy: 0.4292155094679892

![Confusion matrix](dev_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.5487 | 0.5872 | 0.5673 | 470 |
| joy | 0.3264 | 0.3865 | 0.3539 | 163 |
| surprise | 0.3675 | 0.4067 | 0.3861 | 150 |
| anger | 0.3154 | 0.3072 | 0.3113 | 153 |
| sadness | 0.2874 | 0.2252 | 0.2525 | 111 |
| disgust | 0.5000 | 0.0455 | 0.0833 | 22 |
| fear | 0.3333 | 0.0750 | 0.1224 | 40 |

Lowest class F1: disgust, fear. Inspect real errors before assigning causes.

Examples: [dev_review_examples.csv](dev_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Test split

- Weighted F1: 0.41662052652317283
- Macro F1: 0.24871046087053778
- Accuracy: 0.42375478927203064

![Confusion matrix](test_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.5733 | 0.5852 | 0.5792 | 1256 |
| joy | 0.3226 | 0.3483 | 0.3349 | 402 |
| surprise | 0.3098 | 0.4057 | 0.3513 | 281 |
| anger | 0.2715 | 0.2377 | 0.2535 | 345 |
| sadness | 0.1864 | 0.1587 | 0.1714 | 208 |
| disgust | 0.1818 | 0.0294 | 0.0506 | 68 |
| fear | 0.0000 | 0.0000 | 0.0000 | 50 |

Lowest class F1: fear, disgust. Inspect real errors before assigning causes.

Examples: [test_review_examples.csv](test_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Measured hardware and efficiency

See [hardware.json](hardware.json).

Latency is batch 1 including preprocessing, forward and postprocessing, excluding loading.

## Run configuration

~~~json
{
  "model_name": "TF-IDF + Logistic Regression",
  "seed": 42,
  "n_context": 3,
  "n_future": 0,
  "with_speaker": true,
  "selection_split": "dev",
  "C": 8,
  "class_weight": "balanced",
  "ngram_range": [
    1,
    2
  ],
  "max_features": 50000,
  "min_df": 2,
  "lowercase": true,
  "sublinear_tf": true
}
~~~

## Evidence gaps / limitations

- Learning curves: trainer_state.json/log_history unavailable; no curve was invented.

Text-only English MELD / Friends dialogues; multilingual and clinical performance is unvalidated.
Softmax confidence is not a calibrated probability of correctness.
Test error inspection is final reporting, not another hyperparameter-selection round.
