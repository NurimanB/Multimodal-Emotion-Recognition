# microsoft/deberta-v3-base

All values below come from recorded artifacts; missing evidence is stated explicitly.

## Dev split

- Weighted F1: 0.6324116142539209
- Macro F1: 0.5063426413603583
- Accuracy: 0.6357078449053201

![Confusion matrix](dev_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7405 | 0.7894 | 0.7642 | 470 |
| joy | 0.6182 | 0.6258 | 0.6220 | 163 |
| surprise | 0.6712 | 0.6533 | 0.6622 | 150 |
| anger | 0.5789 | 0.4314 | 0.4944 | 153 |
| sadness | 0.4098 | 0.4505 | 0.4292 | 111 |
| disgust | 0.2500 | 0.2727 | 0.2609 | 22 |
| fear | 0.3243 | 0.3000 | 0.3117 | 40 |

Lowest class F1: disgust, fear. Inspect real errors before assigning causes.

Examples: [dev_review_examples.csv](dev_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Test split

- Weighted F1: 0.6406311546273759
- Macro F1: 0.4696796117294168
- Accuracy: 0.6406130268199234

![Confusion matrix](test_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7788 | 0.7850 | 0.7819 | 1256 |
| joy | 0.5959 | 0.6493 | 0.6214 | 402 |
| surprise | 0.5870 | 0.5765 | 0.5817 | 281 |
| anger | 0.5820 | 0.4319 | 0.4958 | 345 |
| sadness | 0.3636 | 0.4231 | 0.3911 | 208 |
| disgust | 0.2143 | 0.1765 | 0.1935 | 68 |
| fear | 0.1842 | 0.2800 | 0.2222 | 50 |

Lowest class F1: disgust, fear. Inspect real errors before assigning causes.

Examples: [test_review_examples.csv](test_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Learning curves

![Learning curves](learning_curves.png)

Training points are logged batch losses; validation points use the validation set.

## Measured hardware and efficiency

See [hardware.json](hardware.json).

Latency is batch 1 including preprocessing, forward and postprocessing, excluding loading.

## Run configuration

~~~json
{
  "model_name": "microsoft/deberta-v3-base",
  "data_dir": "/content/drive/MyDrive/diploma-mer/data/meld",
  "output_dir": "/content/drive/MyDrive/diploma-mer/defense/defense_v1/deberta_s42",
  "checkpoint_dir": "/content/checkpoints/defense_v1/deberta_s42",
  "n_context": 3,
  "n_future": 0,
  "with_speaker": true,
  "max_length": 256,
  "epochs": 6,
  "lr": 2e-05,
  "batch_size": 4,
  "grad_accum": 4,
  "weight_decay": 0.01,
  "warmup_ratio": 0.1,
  "class_weights": true,
  "class_weight_power": 0.5,
  "focal_gamma": 0.0,
  "early_stopping_patience": 2,
  "gradient_checkpointing": true,
  "seed": 42,
  "limit_train": null,
  "limit_eval": null,
  "save_model": true,
  "evaluate_test": false,
  "save_only_model": true,
  "resume_from_checkpoint": null,
  "logging_steps": 25,
  "save_probs": true
}
~~~

## Evidence gaps / limitations


Text-only English MELD / Friends dialogues; multilingual and clinical performance is unvalidated.
Softmax confidence is not a calibrated probability of correctness.
Test error inspection is final reporting, not another hyperparameter-selection round.
