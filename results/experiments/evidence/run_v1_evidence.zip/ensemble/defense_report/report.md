# Dev-selected probability ensemble

All values below come from recorded artifacts; missing evidence is stated explicitly.

## Dev split

- Weighted F1: 0.6645841187074325
- Macro F1: 0.5521368082685728
- Accuracy: 0.6699729486023445

![Confusion matrix](dev_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7529 | 0.8234 | 0.7866 | 470 |
| joy | 0.6185 | 0.6564 | 0.6369 | 163 |
| surprise | 0.6331 | 0.7133 | 0.6708 | 150 |
| anger | 0.7368 | 0.4575 | 0.5645 | 153 |
| sadness | 0.5769 | 0.4054 | 0.4762 | 111 |
| disgust | 0.2667 | 0.3636 | 0.3077 | 22 |
| fear | 0.3800 | 0.4750 | 0.4222 | 40 |

Lowest class F1: disgust, fear. Inspect real errors before assigning causes.

Examples: [dev_review_examples.csv](dev_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Test split

- Weighted F1: 0.6575566645512206
- Macro F1: 0.5093340333581303
- Accuracy: 0.660536398467433

![Confusion matrix](test_confusion_matrix.png)

| Emotion | Precision | Recall | F1 | Support |
|---|---:|---:|---:|---:|
| neutral | 0.7812 | 0.8073 | 0.7940 | 1256 |
| joy | 0.6044 | 0.6766 | 0.6385 | 402 |
| surprise | 0.5434 | 0.6014 | 0.5709 | 281 |
| anger | 0.6360 | 0.4406 | 0.5205 | 345 |
| sadness | 0.4898 | 0.3462 | 0.4056 | 208 |
| disgust | 0.3200 | 0.3529 | 0.3357 | 68 |
| fear | 0.2333 | 0.4200 | 0.3000 | 50 |

Lowest class F1: fear, disgust. Inspect real errors before assigning causes.

Examples: [test_review_examples.csv](test_review_examples.csv).
Selection: up to five correct and five incorrect; class diversity then confidence.
Diagnostic examples do not estimate the frequency of errors.

## Evidence gaps / limitations

- Learning curves: trainer_state.json/log_history unavailable; no curve was invented.
- Hardware, parameter count and latency: not measured in this legacy JSON.

Text-only English MELD / Friends dialogues; multilingual and clinical performance is unvalidated.
Softmax confidence is not a calibrated probability of correctness.
Test error inspection is final reporting, not another hyperparameter-selection round.
